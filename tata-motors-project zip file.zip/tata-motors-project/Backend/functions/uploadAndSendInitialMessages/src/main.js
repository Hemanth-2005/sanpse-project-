import { Client, Users, Databases, Storage, ID } from 'node-appwrite';

// V1.0 ENHANCEMENT: Improved Appwrite function for handling lead uploads and initial message sending
export default async ({ req, res, log, error }) => {
  // Initialize Appwrite client
  const client = new Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(req.headers['x-appwrite-key'] ?? '');
  
  // Initialize Appwrite services
  const users = new Users(client);
  const databases = new Databases(client);
  const storage = new Storage(client);
  
  // Database and collection IDs from appwrite.json
  const DATABASE_ID = '687f278f00353df5ecf2'; // Leads DB
  const COLLECTION_ID = '687f27b90003f46014dd'; // leads collection
  
  // Handle ping requests for health checks
  if (req.path === "/ping") {
    return res.text("Pong");
  }
  
  try {
    // V1.0 ENHANCEMENT: Handle file upload
    if (req.method === 'POST' && req.path === '/upload') {
      // Parse the request body
      const body = JSON.parse(req.body);
      const leadsData = body.leads;
      const leadCount = body.leadCount || leadsData.length; // Use specified count or all leads
      
      log(`Processing ${leadCount} leads out of ${leadsData.length} total`);
      
      // Process only the specified number of leads
      const leadsToProcess = leadsData.slice(0, leadCount);
      
      // Store leads in the database
      const uploadResults = await Promise.all(leadsToProcess.map(async (lead) => {
        try {
          // Create a new document in the leads collection
          const newLead = await databases.createDocument(
            DATABASE_ID,
            COLLECTION_ID,
            ID.unique(),
            {
              opportunityName: lead['Opportunity Name'] || '',
              salesTeam: lead['Sales Team'] || '',
              productVC: lead['Product/VC#'] || '',
              customerName: lead['Customer Name'] || '',
              phone: lead.Phone || '',
              model: lead.Model || '',
              parentProductLine: lead['Parent Product Line'] || '',
              productLine: lead['Product Line'] || '',
              sentAt: new Date().toISOString(),
              status: 'Not Contacted',
              likelihood: 'Medium',
              chatHistory: JSON.stringify([]),
              summary: ''
            }
          );
          
          return { success: true, id: newLead.$id, lead };
        } catch (err) {
          error(`Failed to create lead: ${err.message}`);
          return { success: false, error: err.message, lead };
        }
      }));
      
      // Count successful uploads
      const successCount = uploadResults.filter(result => result.success).length;
      
      log(`Successfully uploaded ${successCount} leads`);
      
      return res.json({
        success: true,
        message: `Successfully processed ${successCount} out of ${leadsToProcess.length} leads`,
        results: uploadResults
      });
    }
    
    // V1.0 ENHANCEMENT: Handle sending initial messages
    if (req.method === 'POST' && req.path === '/send-messages') {
      const body = JSON.parse(req.body);
      const leadIds = body.leadIds;
      
      if (!leadIds || !Array.isArray(leadIds)) {
        return res.json({ success: false, message: 'Invalid request: leadIds array is required' }, 400);
      }
      
      log(`Sending initial messages to ${leadIds.length} leads`);
      
      // Simulate sending messages (in a real implementation, this would connect to WhatsApp API)
      const results = await Promise.all(leadIds.map(async (leadId) => {
        try {
          // Get the lead details
          const lead = await databases.getDocument(DATABASE_ID, COLLECTION_ID, leadId);
          
          // Update the lead status to indicate message was sent
          await databases.updateDocument(
            DATABASE_ID,
            COLLECTION_ID,
            leadId,
            {
              status: 'Message Sent',
              sentAt: new Date().toISOString()
            }
          );
          
          return { success: true, leadId, message: `Message sent to ${lead.customerName}` };
        } catch (err) {
          error(`Failed to send message to lead ${leadId}: ${err.message}`);
          return { success: false, leadId, error: err.message };
        }
      }));
      
      // Count successful messages
      const successCount = results.filter(result => result.success).length;
      
      log(`Successfully sent ${successCount} messages`);
      
      return res.json({
        success: true,
        message: `Successfully sent ${successCount} out of ${leadIds.length} messages`,
        results
      });
    }
    
    // Default response for other requests
    return res.json({
      success: true,
      message: "Synapse Lead Management API",
      endpoints: [
        { path: "/upload", method: "POST", description: "Upload leads data" },
        { path: "/send-messages", method: "POST", description: "Send initial messages to leads" },
        { path: "/ping", method: "GET", description: "Health check endpoint" }
      ]
    });
};
}
