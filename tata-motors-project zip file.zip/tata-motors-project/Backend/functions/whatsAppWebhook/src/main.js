import { Client, Users, Databases, ID } from 'node-appwrite';

// V1.0 ENHANCEMENT: Improved WhatsApp webhook handler for conversation tracking and lead management
export default async ({ req, res, log, error }) => {
  // Initialize Appwrite client
  const client = new Client()
    .setEndpoint(process.env.APPWRITE_FUNCTION_API_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(req.headers['x-appwrite-key'] ?? '');
  
  // Initialize Appwrite services
  const users = new Users(client);
  const databases = new Databases(client);
  
  // Database and collection IDs from appwrite.json
  const DATABASE_ID = '687f278f00353df5ecf2'; // Leads DB
  const COLLECTION_ID = '687f27b90003f46014dd'; // leads collection
  
  // Handle ping requests for health checks
  if (req.path === "/ping") {
    return res.text("Pong");
  }
  
  try {
    // V1.0 ENHANCEMENT: Handle incoming WhatsApp messages
    if (req.method === 'POST' && req.path === '/webhook') {
      const body = JSON.parse(req.body);
      
      // Extract message data
      const { from, text, timestamp } = body;
      
      if (!from || !text) {
        return res.json({ success: false, message: 'Invalid webhook data' }, 400);
      }
      
      log(`Received message from ${from}: ${text}`);
      
      // Find the lead by phone number
      const leads = await databases.listDocuments(
        DATABASE_ID,
        COLLECTION_ID,
        [databases.queries.equal('phone', from)]
      );
      
      if (leads.total === 0) {
        log(`No lead found with phone number: ${from}`);
        return res.json({ success: false, message: 'Lead not found' }, 404);
      }
      
      const lead = leads.documents[0];
      
      // Update chat history
      let chatHistory = [];
      try {
        chatHistory = JSON.parse(lead.chatHistory || '[]');
      } catch (err) {
        error(`Error parsing chat history: ${err.message}`);
        chatHistory = [];
      }
      
      // Add new message to chat history
      chatHistory.push({
        sender: 'customer',
        message: text,
        timestamp: timestamp || new Date().toISOString()
      });
      
      // Determine new status based on message content
      let newStatus = lead.status;
      let newLikelihood = lead.likelihood || 'Medium';
      
      // Simple keyword-based status updates
      const lowerText = text.toLowerCase();
      if (lowerText.includes('interested') || lowerText.includes('book') || lowerText.includes('test drive')) {
        newStatus = 'Interested';
        newLikelihood = 'High';
      } else if (lowerText.includes('price') || lowerText.includes('cost') || lowerText.includes('offer')) {
        newStatus = 'Price Inquiry';
        newLikelihood = 'Medium';
      } else if (lowerText.includes('not interested') || lowerText.includes('stop') || lowerText.includes('unsubscribe')) {
        newStatus = 'Not Interested';
        newLikelihood = 'Low';
      }
      
      // Update the lead with new chat history and status
      await databases.updateDocument(
        DATABASE_ID,
        COLLECTION_ID,
        lead.$id,
        {
          chatHistory: JSON.stringify(chatHistory),
          status: newStatus,
          likelihood: newLikelihood,
          lastUpdated: new Date().toISOString()
        }
      );
      
      // V1.0 ENHANCEMENT: Generate conversation summary if needed
      if (chatHistory.length >= 3 && !lead.summary) {
        // In a real implementation, this would call an AI service to generate a summary
        // For now, we'll create a simple summary
        const summary = `Conversation with ${lead.customerName} about ${lead.model}. ` +
                       `Current status: ${newStatus}. Likelihood: ${newLikelihood}.`;
        
        await databases.updateDocument(
          DATABASE_ID,
          COLLECTION_ID,
          lead.$id,
          { summary }
        );
        
        log(`Generated summary for lead ${lead.$id}`);
      }
      
      return res.json({
        success: true,
        message: 'Message processed successfully',
        leadId: lead.$id
      });
    }
    
    // V1.0 ENHANCEMENT: Endpoint to manually generate or update a summary
    if (req.method === 'POST' && req.path === '/generate-summary') {
      const body = JSON.parse(req.body);
      const { leadId } = body;
      
      if (!leadId) {
        return res.json({ success: false, message: 'Lead ID is required' }, 400);
      }
      
      // Get the lead
      const lead = await databases.getDocument(DATABASE_ID, COLLECTION_ID, leadId);
      
      // Parse chat history
      let chatHistory = [];
      try {
        chatHistory = JSON.parse(lead.chatHistory || '[]');
      } catch (err) {
        error(`Error parsing chat history: ${err.message}`);
        chatHistory = [];
      }
      
      if (chatHistory.length === 0) {
        return res.json({ success: false, message: 'No conversation to summarize' }, 400);
      }
      
      // In a real implementation, this would call an AI service to generate a summary
      // For now, we'll create a simple summary
      const summary = `Conversation with ${lead.customerName} about ${lead.model}. ` +
                     `Current status: ${lead.status}. Likelihood: ${lead.likelihood}. ` +
                     `${chatHistory.length} messages exchanged.`;
      
      // Update the lead with the new summary
      await databases.updateDocument(
        DATABASE_ID,
        COLLECTION_ID,
        leadId,
        { summary }
      );
      
      return res.json({
        success: true,
        message: 'Summary generated successfully',
        summary
      });
    }
    
    // Default response for other requests
    return res.json({
      success: true,
      message: "Synapse WhatsApp Webhook API",
      endpoints: [
        { path: "/webhook", method: "POST", description: "Handle incoming WhatsApp messages" },
        { path: "/generate-summary", method: "POST", description: "Generate or update a conversation summary" },
        { path: "/ping", method: "GET", description: "Health check endpoint" }
      ]
    });
  } catch (err) {
    error(`Error processing request: ${err.message}`);
    return res.json({ success: false, message: `Error: ${err.message}` }, 500);
  }
};
