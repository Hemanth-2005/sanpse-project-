import router from './components/router.js';

// V1.0 ENHANCEMENT: Optimized function to load shared header and footer components with improved layout stability
const loadSharedComponents = async () => {
    try {
        // Create promises for both header and footer to load in parallel
        const headerPromise = fetch('/src/components/header.html').then(res => res.text());
        const footerPromise = fetch('/src/components/footer.html').then(res => res.text());
        
        // Wait for both to complete
        const [headerHtml, footerHtml] = await Promise.all([headerPromise, footerPromise]);
        
        // Apply header only if container exists and content is different
        const headerContainer = document.querySelector('header');
        if (headerContainer && headerContainer.outerHTML !== headerHtml) {
            // Preserve active navigation state
            const currentPath = window.location.pathname;
            headerContainer.outerHTML = headerHtml;
            
            // Re-highlight the active navigation link
            setTimeout(() => {
                const navLinks = document.querySelectorAll('.nav-link');
                navLinks.forEach(link => {
                    if (link.getAttribute('href') === currentPath) {
                        link.classList.add('text-highlight');
                        link.classList.remove('text-secondary-text');
                    } else {
                        link.classList.add('text-secondary-text');
                        link.classList.remove('text-highlight');
                    }
                });
            }, 0);
        }
        
        // Apply footer only if container exists and content is different
        const footerContainer = document.querySelector('footer');
        if (footerContainer && footerContainer.outerHTML !== footerHtml) {
            footerContainer.outerHTML = footerHtml;
        }
    } catch (error) {
        console.error('Error loading shared components:', error);
    }
};

// Function to load page-specific scripts
const loadPageScript = (page) => {
    const pageName = page.split('/').pop().split('.html')[0];
    switch (pageName) {
        case 'dashboard':
            import('./pages/dashboard.js').then(module => module.init());
            break;
        // V6.0 FEATURE: Removed conversation-intelligence case as part of the architectural changes
        case 'feedback':
            import('./pages/feedback.js').then(module => module.init());
            break;
        // V6.0 FEATURE: Added new pages for offers and payment
        case 'offers':
            import('./pages/offers.js').then(module => module.init());
            break;
        case 'payment':
            import('./pages/payment.js').then(module => module.init());
            break;
        // Add other cases for other pages if they have specific JS
    }
};

// Initialize the router
router.init();

// V1.0 ENHANCEMENT: Load shared components first to prevent layout shifts
loadSharedComponents().then(() => {
    // Handle initial page load after components are loaded
    loadPageScript(window.location.pathname);
});

// Listen for page changes from the router
document.addEventListener('page-load', (e) => {
    // V1.0 ENHANCEMENT: Reload shared components on page change
    loadSharedComponents().then(() => {
        loadPageScript(e.detail.page);
    });
});


// V3.0 ENHANCEMENT: Added support for Likelihood column with color-coded status tags
function renderLeadsTable(leads) {
    const tableBody = document.getElementById('leads-table-body');
    if (!tableBody) return;
    
    tableBody.innerHTML = '';
    
    leads.forEach(lead => {
        const row = document.createElement('tr');
        row.className = 'transition-all duration-300 hover:bg-[rgba(45,74,83,0.2)]';
        row.setAttribute('data-lead-id', lead.id);
        
        // Add click event to show lead activity modal
        row.addEventListener('click', () => showLeadActivityModal(lead));
        
        // Create cells for each column
        const columns = [
            lead.opportunityName,
            lead.salesTeam,
            lead.productVC,
            lead.customerName,
            lead.phone,
            lead.model,
            lead.parentProductLine,
            lead.productLine,
            formatDate(lead.sentAt),
            createStatusBadge(lead.status),
            createLikelihoodBadge(lead.likelihood || getLikelihoodFromStatus(lead.status)),
            createActionButtons(lead)
        ];
        
        // Add cells to row
        columns.forEach((content, index) => {
            const cell = document.createElement('td');
            cell.className = 'py-4 px-6 whitespace-nowrap text-sm';
            
            // Apply right alignment to the actions column
            if (index === columns.length - 1) {
                cell.className += ' text-right';
            }
            
            // If content is a DOM element, append it, otherwise set as innerHTML
            if (content instanceof HTMLElement) {
                cell.appendChild(content);
            } else {
                cell.innerHTML = content;
            }
            
            row.appendChild(cell);
        });
        
        tableBody.appendChild(row);
    });
}

// V3.0 ENHANCEMENT: Create color-coded likelihood badge
function createLikelihoodBadge(likelihood) {
    const badge = document.createElement('span');
    let bgColor, textColor;
    
    switch(likelihood.toLowerCase()) {
        case 'high':
            bgColor = 'bg-likelihood-high/20';
            textColor = 'text-likelihood-high';
            break;
        case 'medium':
            bgColor = 'bg-likelihood-medium/20';
            textColor = 'text-likelihood-medium';
            break;
        case 'low':
            bgColor = 'bg-likelihood-low/20';
            textColor = 'text-likelihood-low';
            break;
        default:
            bgColor = 'bg-gray-500/20';
            textColor = 'text-gray-500';
    }
    
    badge.className = `inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${bgColor} ${textColor} backdrop-blur-sm border border-${textColor}/20`;
    badge.innerHTML = likelihood;
    
    return badge;
}

// V3.0 ENHANCEMENT: Determine likelihood based on status
function getLikelihoodFromStatus(status) {
    switch(status.toLowerCase()) {
        case 'responded':
        case 'connected':
            return 'High';
        case 'sent':
            return 'Medium';
        case 'failed':
        case 'pending':
            return 'Low';
        default:
            return 'Medium';
    }
}

// V3.0 ENHANCEMENT: Show lead activity modal
function showLeadActivityModal(lead) {
    const modal = document.getElementById('lead-activity-modal');
    const content = document.getElementById('lead-activity-content');
    
    if (!modal || !content) return;
    
    // Clear previous content
    content.innerHTML = '';
    
    // Create lead info header
    const header = document.createElement('div');
    header.className = 'mb-6 pb-4 border-b border-[rgba(175,179,183,0.2)]';
    header.innerHTML = `
        <h3 class="text-xl font-semibold mb-2">${lead.customerName}</h3>
        <p class="text-secondary-text">${lead.phone} • ${lead.model}</p>
    `;
    content.appendChild(header);
    
    // Create mock activity timeline
    const activities = [
        { type: 'message', text: 'Replied: "I would like to book a test drive"', timestamp: '2 hours ago', status: 'success' },
        { type: 'call', text: 'Connected with Sales Exec: John Smith', timestamp: 'Yesterday, 3:45 PM', status: 'success' },
        { type: 'message', text: 'Initial message sent', timestamp: '2 days ago', status: 'info' }
    ];
    
    // Create activity timeline
    const timeline = document.createElement('div');
    timeline.className = 'space-y-4';
    
    activities.forEach(activity => {
        const item = document.createElement('div');
        item.className = 'flex items-start';
        
        // Icon based on activity type
        let iconClass = 'fas fa-comment';
        if (activity.type === 'call') iconClass = 'fas fa-phone-alt';
        
        // Status color
        let statusColor = 'text-status-green';
        if (activity.status === 'info') statusColor = 'text-teal-primary';
        if (activity.status === 'warning') statusColor = 'text-status-yellow';
        if (activity.status === 'error') statusColor = 'text-status-red';
        
        item.innerHTML = `
            <div class="flex-shrink-0 h-8 w-8 rounded-full ${statusColor} bg-${statusColor}/10 flex items-center justify-center mr-4">
                <i class="${iconClass}"></i>
            </div>
            <div>
                <p class="font-medium">${activity.text}</p>
                <p class="text-sm text-secondary-text">${activity.timestamp}</p>
            </div>
        `;
        
        timeline.appendChild(item);
    });
    
    content.appendChild(timeline);
    
    // Show modal with animation
    modal.classList.remove('hidden');
    setTimeout(() => {
        modal.querySelector('.modal-content').classList.remove('scale-95', 'opacity-0');
        modal.querySelector('.modal-content').classList.add('scale-100', 'opacity-100');
    }, 10);
}
