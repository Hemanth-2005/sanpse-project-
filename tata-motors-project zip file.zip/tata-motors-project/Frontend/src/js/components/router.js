/**
 * A lightweight client-side router that uses the fetch API to load page content.
 * It intercepts clicks on navigation links, fetches the content of the target page's <main> tag,
 * and replaces the current page's <main> content with the new content.
 */

const router = {
    init: () => {
        document.addEventListener('click', (e) => {
            const target = e.target.closest('.nav-link');
            if (target) {
                e.preventDefault();
                const url = target.href;
                router.navigateTo(url);
            }
        });

        window.addEventListener('popstate', (e) => {
            if (e.state && e.state.url) {
                router.loadPage(e.state.url, false);
            }
        });
    },

    navigateTo: (url) => {
        history.pushState({ url }, '', url);
        router.loadPage(url);
    },

    loadPage: async (url, pushState = true) => {
        const mainContent = document.getElementById('main-content');
        if (!mainContent) {
            console.error('Main content area not found.');
            return;
        }

        mainContent.classList.add('fade-out');

        try {
            const response = await fetch(url);
            if (!response.ok) {
                throw new Error('Failed to fetch page content.');
            }
            const text = await response.text();
            const parser = new DOMParser();
            const doc = parser.parseFromString(text, 'text/html');
            const newMainContent = doc.getElementById('main-content');

            if (newMainContent) {
                mainContent.innerHTML = newMainContent.innerHTML;
                document.title = doc.title;

                mainContent.classList.remove('fade-out');
                mainContent.classList.add('fade-in');

                // After loading the page, dispatch a custom event
                const pageLoadEvent = new CustomEvent('page-load', { detail: { page: url } });
                document.dispatchEvent(pageLoadEvent);

            } else {
                throw new Error('<main> content not found in fetched page.');
            }
        } catch (error) {
            console.error('Error loading page:', error);
            mainContent.innerHTML = '<p>Error loading page. Please try again.</p>';
            mainContent.classList.remove('fade-out');
        }
    },
};

export default router;
