// src/js/mock-data.js

// V4.0 CORRECTED: Mock data aligned with the Synapse project's dashboard columns.
// This data is structured to match the <thead> in dashboard.html and includes
// extra properties like 'likelihood' and 'activityLog' for other UI features.

const mockLeads = [
  {
    id: 1,
    "Opportunity Name": "5-295SOCK9",
    "Sales Team": "PLM_3003010",
    "Sales Executive Number": "+91 9988776655",
    "Product/VC#": "54650327AK8R",
    "Customer Name": "Ameya Hegadi",
    "Phone": "9380679760",
    "Model": "Harrier Smart",
    "Parent Product Line": "Harrier",
    "Product Line": "Harrier Smart",
    "Sent At": "2025-07-19 10:15 AM",
    "Status": "Not Responded",
    likelihood: "Medium",
    activityLog: [
      { event: "Message Sent", timestamp: "2025-07-19 10:15 AM", details: "Initial outreach via WhatsApp." }
    ]
  },
  {
    id: 2,
    "Opportunity Name": "5-295NPWLT",
    "Sales Team": "NR2_3003010",
    "Sales Executive Number": "+91 9876543210",
    "Product/VC#": "54643025ALOR",
    "Customer Name": "Santosha Yankanchi",
    "Phone": "8217571674",
    "Model": "Nexon Creative+ AMT",
    "Parent Product Line": "Nexon",
    "Product Line": "Nexon Creative + AMT DT 1.5",
    "Sent At": "2025-07-19 10:16 AM",
    "Status": "Slot: 11:00 AM",
    likelihood: "High",
    activityLog: [
      { event: "Message Sent", timestamp: "2025-07-19 10:16 AM", details: "Initial outreach via WhatsApp." },
      { event: "Replied", timestamp: "2025-07-19 11:05 AM", details: "Clicked 'Book Test Drive'." },
      { event: "Replied", timestamp: "2025-07-19 11:06 AM", details: "Selected time slot: 11:00 AM - 1:00 PM." }
    ]
  },
  {
    id: 3,
    "Opportunity Name": "5-2958EO0P",
    "Sales Team": "JH2_3003010",
    "Sales Executive Number": "+91 9123456789",
    "Product/VC#": "54856324AK4P",
    "Customer Name": "Vijay Madar",
    "Phone": "8217719631",
    "Model": "Punch",
    "Parent Product Line": "Punch",
    "Product Line": "Punch Creative",
    "Sent At": "2025-07-19 10:17 AM",
    "Status": "Contacted Sales",
    likelihood: "High",
    activityLog: [
      { event: "Message Sent", timestamp: "2025-07-19 10:17 AM", details: "Initial outreach via WhatsApp." },
      { event: "Replied", timestamp: "2025-07-19 01:20 PM", details: "Clicked 'Contact Us'." },
      { event: "Connected", timestamp: "2025-07-19 01:20 PM", details: "Assigned to Sales Executive: +91 9988776655." }
    ]
  },
  {
    id: 4,
    "Opportunity Name": "5-2AEGKLDE",
    "Sales Team": "PSJ_3003010",
    "Sales Executive Number": "+91 9001122334",
    "Product/VC#": "54757224AK9R",
    "Customer Name": "Vilas Sindhe",
    "Phone": "9740024517",
    "Model": "Tiago XTA",
    "Parent Product Line": "Tiago",
    "Product Line": "Tiago (P) XTA",
    "Sent At": "2025-07-18 09:30 AM",
    "Status": "Not Responded",
    likelihood: "Low",
    activityLog: [
      { event: "Message Sent", timestamp: "2025-07-18 09:30 AM", details: "Initial outreach via WhatsApp." }
    ]
  },
  {
    id: 5,
    "Opportunity Name": "5-2AEE2G0X",
    "Sales Team": "PD3_3003010",
    "Sales Executive Number": "+91 9112233445",
    "Product/VC#": "54641227AM3R",
    "Customer Name": "Basavraj Pattar",
    "Phone": "9900920397",
    "Model": "Nexon Pure+ S",
    "Parent Product Line": "Nexon",
    "Product Line": "Nexon Pure + S 1.5",
    "Sent At": "2025-07-18 09:31 AM",
    "Status": "Slot: 03:00 PM",
    likelihood: "Medium",
    activityLog: [
        { event: "Message Sent", timestamp: "2025-07-18 09:31 AM", details: "Initial outreach via WhatsApp." },
        { event: "Replied", timestamp: "2025-07-18 10:15 AM", details: "Clicked 'Book Test Drive'." },
        { event: "Replied", timestamp: "2025-07-18 10:16 AM", details: "Selected time slot: 3:00 PM - 5:00 PM." }
    ]
  },
  {
    id: 6,
    "Opportunity Name": "5-2AE4N3N9",
    "Sales Team": "PD3_3003010",
    "Sales Executive Number": "+91 9223344556",
    "Product/VC#": "54912345BC7D",
    "Customer Name": "Shridhar",
    "Phone": "7019686725",
    "Model": "Altroz XZ",
    "Parent Product Line": "Altroz",
    "Product Line": "Altroz XZ+ (S)",
    "Sent At": "2025-07-17 02:00 PM",
    "Status": "Not Responded",
    likelihood: "Medium",
    activityLog: [
        { event: "Message Sent", timestamp: "2025-07-17 02:00 PM", details: "Initial outreach via WhatsApp." }
    ]
  }
];

export default mockLeads;
