// V6.0 FEATURE: Payment Management JavaScript

// V6.0 FEATURE: Initialize the payment modal and handle payment logic
const initPaymentModal = () => {
    const paymentBtn = document.getElementById('payment-btn');
    const paymentModal = document.getElementById('payment-modal');
    const closeModalBtn = document.getElementById('close-modal');
    const paymentForm = document.getElementById('payment-form');
    
    if (!paymentBtn || !paymentModal || !closeModalBtn || !paymentForm) return;
    
    // Open modal when payment button is clicked
    paymentBtn.addEventListener('click', () => {
        paymentModal.classList.remove('hidden');
        document.body.style.overflow = 'hidden'; // Prevent scrolling when modal is open
    });
    
    // Close modal when close button is clicked
    closeModalBtn.addEventListener('click', () => {
        closeModal();
    });
    
    // Close modal when clicking outside the modal content
    paymentModal.addEventListener('click', (event) => {
        if (event.target === paymentModal) {
            closeModal();
        }
    });
    
    // Handle form submission
    paymentForm.addEventListener('submit', (event) => {
        event.preventDefault();
        
        // V6.0 ENHANCEMENT: Added form validation before processing payment
        if (!validatePaymentForm()) {
            return;
        }
        
        // Show processing state
        const submitBtn = paymentForm.querySelector('button[type="submit"]');
        const originalText = submitBtn.innerHTML;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Processing...';
        submitBtn.disabled = true;
        
        // Simulate payment processing
        setTimeout(() => {
            // Show success message
            showNotification('Payment processed successfully!');
            
            // Close modal
            closeModal();
            
            // Reset button
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
            
            // Reset form
            paymentForm.reset();
        }, 2000);
    });
    
    // Function to close modal
    const closeModal = () => {
        paymentModal.classList.add('hidden');
        document.body.style.overflow = ''; // Re-enable scrolling
    };
};

// V6.0 FEATURE: Comprehensive form validation for payment
const validatePaymentForm = () => {
    const cardNumber = document.getElementById('card-number').value.replace(/\s/g, '');
    const expiry = document.getElementById('expiry').value;
    const cvc = document.getElementById('cvc').value;
    const name = document.getElementById('name').value;
    
    let isValid = true;
    
    // Validate card number (should be 16 digits and pass Luhn algorithm)
    if (!/^\d{16}$/.test(cardNumber) || !validateCardNumber(cardNumber)) {
        showNotification('Please enter a valid card number', 'error');
        isValid = false;
    }
    
    // Validate expiry date (should be in MM/YY format and not expired)
    if (!validateExpiryDate(expiry)) {
        showNotification('Please enter a valid expiry date (MM/YY)', 'error');
        isValid = false;
    }
    
    // Validate CVC (should be 3 digits)
    if (!/^\d{3}$/.test(cvc)) {
        showNotification('Please enter a valid 3-digit CVC', 'error');
        isValid = false;
    }
    
    // Validate name (should not be empty)
    if (!name.trim()) {
        showNotification('Please enter the name on card', 'error');
        isValid = false;
    }
    
    return isValid;
};

// V6.0 FEATURE: Luhn algorithm for card number validation
const validateCardNumber = (number) => {
    try {
        let sum = 0;
        let shouldDouble = false;
        
        // Loop through values starting from the rightmost digit
        for (let i = number.length - 1; i >= 0; i--) {
            let digit = parseInt(number.charAt(i));
            
            if (shouldDouble) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }
            
            sum += digit;
            shouldDouble = !shouldDouble;
        }
        
        return (sum % 10) === 0;
    } catch (error) {
        console.error('Error validating card number:', error);
        return false;
    }
};

// V6.0 FEATURE: Expiry date validation
const validateExpiryDate = (expiry) => {
    try {
        // Check format
        if (!/^\d{2}\/\d{2}$/.test(expiry)) {
            return false;
        }
        
        const [month, year] = expiry.split('/');
        const currentDate = new Date();
        const currentYear = currentDate.getFullYear() % 100; // Get last 2 digits
        const currentMonth = currentDate.getMonth() + 1; // January is 0
        
        // Convert to numbers
        const expiryMonth = parseInt(month, 10);
        const expiryYear = parseInt(year, 10);
        
        // Validate month
        if (expiryMonth < 1 || expiryMonth > 12) {
            return false;
        }
        
        // Check if expired
        if (expiryYear < currentYear || (expiryYear === currentYear && expiryMonth < currentMonth)) {
            return false;
        }
        
        return true;
    } catch (error) {
        console.error('Error validating expiry date:', error);
        return false;
    }
};

// Function to format currency
const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(amount);
};

// V6.0 FEATURE: Toast notification using new class
const showNotification = (message, type = 'success') => {
    const notification = document.createElement('div');
    notification.className = `toast-notification ${type}`;
    const icon = type === 'success' ? 'check-circle' : 'exclamation-circle';
    const iconColor = type === 'success' ? 'text-status-green' : 'text-status-yellow';
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-${icon} ${iconColor} mr-3"></i>
            <p>${message}</p>
        </div>
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) notification.parentNode.removeChild(notification);
        }, 300);
    }, 3000);
};

// V6.0 FEATURE: Format card number and expiry date inputs
const formatCardNumber = () => {
    const cardNumberInput = document.getElementById('card-number');
    if (!cardNumberInput) return;
    
    cardNumberInput.addEventListener('input', (e) => {
        // Remove all non-digit characters
        let value = e.target.value.replace(/\D/g, '');
        
        // Limit to 16 digits
        value = value.substring(0, 16);
        
        // Add a space after every 4 digits
        value = value.replace(/(.{4})/g, '$1 ').trim();
        
        // Update the input value
        e.target.value = value;
    });
};

const formatExpiryDate = () => {
    const expiryInput = document.getElementById('expiry');
    if (!expiryInput) return;
    
    expiryInput.addEventListener('input', (e) => {
        // Remove all non-digit characters
        let value = e.target.value.replace(/\D/g, '');
        
        // Limit to 4 digits
        value = value.substring(0, 4);
        
        // Add a slash after the first 2 digits
        if (value.length > 2) {
            value = value.substring(0, 2) + '/' + value.substring(2);
        }
        
        // Update the input value
        e.target.value = value;
    });
};

// V6.0 FEATURE: Initialize the payment page
const init = () => {
    try {
        // Initialize payment modal
        initPaymentModal();
        
        // Initialize card input formatting
        formatCardNumber();
        formatExpiryDate();
        
        // Add event listeners for CVC input to limit to 3 digits
        const cvcInput = document.getElementById('cvc');
        if (cvcInput) {
            cvcInput.addEventListener('input', (e) => {
                // Remove all non-digit characters and limit to 3 digits
                e.target.value = e.target.value.replace(/\D/g, '').substring(0, 3);
            });
        }
        
        // Add event listener for name input
        const nameInput = document.getElementById('name');
        if (nameInput) {
            nameInput.addEventListener('input', (e) => {
                // Allow only letters, spaces, and hyphens
                e.target.value = e.target.value.replace(/[^a-zA-Z\s-]/g, '');
            });
        }
        
        console.log('Payment page initialized successfully');
    } catch (error) {
        console.error('Error initializing payment page:', error);
    }
};

document.addEventListener('DOMContentLoaded', init);