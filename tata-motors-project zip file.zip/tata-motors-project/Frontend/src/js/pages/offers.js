// V6.0 FEATURE: Offers Management JavaScript

// Mock data for active offers
const mockOffers = [
    {
        id: 1,
        name: 'Summer Special',
        description: 'Special discount on all Nexon models for the summer season.',
        model: 'Nexon',
        startDate: '2023-06-01',
        endDate: '2023-08-31',
        status: 'Active'
    },
    {
        id: 2,
        name: 'Monsoon Offer',
        description: 'Special financing options for all Safari and Harrier models.',
        model: 'Safari, Harrier',
        startDate: '2023-07-15',
        endDate: '2023-09-30',
        status: 'Active'
    },
    {
        id: 3,
        name: 'Festival Discount',
        description: 'Special discounts on all Tata models during the festival season.',
        model: 'All Models',
        startDate: '2023-09-15',
        endDate: '2023-10-31',
        status: 'Active'
    }
];

// Function to format date as MMM DD, YYYY
const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('en-US', options);
};

// Function to render active offers
const renderActiveOffers = () => {
    const offersContainer = document.getElementById('active-offers');
    if (!offersContainer) return;
    
    // Clear existing offers
    offersContainer.innerHTML = '';
    
    // Render each offer
    mockOffers.forEach(offer => {
        const offerCard = document.createElement('div');
        offerCard.className = 'bg-[rgba(90,99,106,0.1)] backdrop-blur-[12px] border border-[rgba(175,179,183,0.2)] rounded-[10px] p-6 shadow-card hover:transform hover:-translate-y-2 transition-all duration-300';
        
        offerCard.innerHTML = `
            <div class="flex justify-between items-start mb-4">
                <h3 class="text-xl font-bold text-highlight">${offer.name}</h3>
                <span class="px-3 py-1 bg-status-green bg-opacity-20 text-status-green rounded-full text-xs font-medium">${offer.status}</span>
            </div>
            <p class="text-secondary-text mb-4">${offer.description}</p>
            <div class="flex justify-between items-center text-sm">
                <span class="text-teal-primary">${offer.model}</span>
                <span class="text-secondary-text">Ends: ${formatDate(offer.endDate)}</span>
            </div>
        `;
        
        offersContainer.appendChild(offerCard);
    });
};

// V6.0 FEATURE: Handle form submission and show toast notification
const handleFormSubmission = (event) => {
    event.preventDefault();
    
    // Get form values
    const offerName = document.getElementById('offer-name').value;
    const offerDescription = document.getElementById('offer-description').value;
    const applicableModel = document.getElementById('applicable-model').value;
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;
    
    // Create new offer object
    const newOffer = {
        id: mockOffers.length + 1,
        name: offerName,
        description: offerDescription,
        model: applicableModel === 'all' ? 'All Models' : applicableModel.charAt(0).toUpperCase() + applicableModel.slice(1),
        startDate: startDate,
        endDate: endDate,
        status: 'Active'
    };
    
    // Add to mock offers array
    mockOffers.unshift(newOffer);
    
    // Re-render offers
    renderActiveOffers();
    
    // Reset form
    document.getElementById('add-offer-form').reset();
    
    // Show success message
    showNotification('Offer added successfully!');
};

// V6.0 FEATURE: Toast notification using new class
const showNotification = (message) => {
    const notification = document.createElement('div');
    notification.className = 'toast-notification success';
    notification.innerHTML = `
        <div class="flex items-center">
            <i class="fas fa-check-circle text-status-green mr-3"></i>
            <p>${message}</p>
        </div>
    `;
    document.body.appendChild(notification);
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) notification.parentNode.removeChild(notification);
        }, 300);
    }, 3000);
};

// V6.0 FEATURE: Add new model option to the select
const handleModelSelection = () => {
    const modelSelect = document.getElementById('applicable-model');
    if (!modelSelect) return;
    
    modelSelect.addEventListener('change', (event) => {
        if (event.target.value === 'new-model') {
            // Prompt for new model name
            const newModel = prompt('Enter new model name:');
            if (newModel && newModel.trim() !== '') {
                // Create new option
                const newOption = document.createElement('option');
                newOption.value = newModel.toLowerCase().replace(/\s+/g, '-');
                newOption.textContent = newModel;
                
                // Insert before the "Add New Model..." option
                modelSelect.insertBefore(newOption, modelSelect.lastElementChild);
                
                // Select the new option
                modelSelect.value = newOption.value;
            } else {
                // If canceled or empty, revert to first option
                modelSelect.value = 'all';
            }
        }
    });
};

// V6.0 FEATURE: Initialize the page and set default dates
const init = () => {
    // Render active offers
    renderActiveOffers();
    
    // Set up form submission handler
    const offerForm = document.getElementById('add-offer-form');
    if (offerForm) {
        offerForm.addEventListener('submit', handleFormSubmission);
    }
    
    // Set up model selection handler
    handleModelSelection();
    
    // Set default dates
    const startDateInput = document.getElementById('start-date');
    const endDateInput = document.getElementById('end-date');
    
    if (startDateInput && endDateInput) {
        const today = new Date();
        const nextMonth = new Date(today);
        nextMonth.setMonth(today.getMonth() + 1);
        
        startDateInput.valueAsDate = today;
        endDateInput.valueAsDate = nextMonth;
    }
};

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);