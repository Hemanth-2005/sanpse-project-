import * as XLSX from 'xlsx';
import Chart from 'chart.js/auto';
// V2.5 ENHANCEMENT: Imported mock data for initial rendering
import mockLeads from '../mock-data.js';

let leadsData = [...mockLeads]; // Initialize with mock data
let leadStatusChart;
let leadSourceChart;

// V1.0 ENHANCEMENT: Enhanced renderTable function with dynamic action buttons
const renderTable = (data) => {
    const tableBody = document.getElementById('leads-table-body');
    const tableContainer = document.querySelector('.table-container');
    if (!tableBody) return;
    tableBody.innerHTML = '';
    
    // V2.5 ENHANCEMENT: Check if we're on mobile for responsive table cards
    const isMobile = window.innerWidth < 768;
    
    if (isMobile && tableContainer) {
        // V2.5 ENHANCEMENT: Mobile card view implementation
        tableContainer.innerHTML = '';
        data.forEach(lead => {
            const card = document.createElement('div');
            card.className = 'responsive-table-card';
            
            // V1.0 ENHANCEMENT: Create action button based on conversation status
            const actionButton = createActionButton(lead);
            
            card.innerHTML = `
                <div class="mb-2"><span class="responsive-table-card-label">Opportunity Name:</span>${lead['Opportunity Name'] || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Sales Team:</span>${lead['Sales Team'] || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Sales Executive Number:</span>${lead['Sales Executive Number'] || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Product/VC#:</span>${lead['Product/VC#'] || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Customer Name:</span>${lead['Customer Name'] || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Phone:</span>${lead.Phone || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Model:</span>${lead.Model || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Parent Product Line:</span>${lead['Parent Product Line'] || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Product Line:</span>${lead['Product Line'] || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Sent At:</span>${lead['Sent At'] || lead.LastContact || 'N/A'}</div>
                <div class="mb-2"><span class="responsive-table-card-label">Status:</span>
                    <span class="px-2 py-1 rounded-[10px] text-xs font-medium ${lead.Status === 'Qualified' ? 'bg-status-green bg-opacity-20 text-status-green' : 
                    lead.Status === 'Contacted' ? 'bg-status-yellow bg-opacity-20 text-status-yellow' : 
                    lead.Status === 'Lost' ? 'bg-status-red bg-opacity-20 text-status-red' : 
                    'bg-teal-primary bg-opacity-20 text-teal-primary'}">  
                    ${lead.Status}
                    </span>
                </div>
                <div class="mt-4 flex justify-end">
                    <div id="action-btn-container-${lead.id}"></div>
                </div>
            `;
            
            card.addEventListener('click', (e) => {
                // Don't trigger detail view if clicking on the action button
                if (!e.target.closest('#action-btn-container-' + lead.id)) {
                    showLeadDetail(lead);
                }
            });
            
            tableContainer.appendChild(card);
            
            // Append the action button to its container
            setTimeout(() => {
                const container = document.getElementById(`action-btn-container-${lead.id}`);
                if (container) container.appendChild(actionButton);
            }, 0);
        });
    } else {
        // Desktop table view
        data.forEach(lead => {
            const row = document.createElement('tr');
            row.className = 'transition-all duration-300 hover:bg-[rgba(45,74,83,0.2)]';
            row.setAttribute('data-lead-id', lead.id);
            
            // V1.0 ENHANCEMENT: Create action button based on conversation status
            const actionButton = createActionButton(lead);
            
            // Create cells for each column
            const columns = [
                lead['Opportunity Name'] || 'N/A',
                lead['Sales Team'] || 'N/A',
                lead['Sales Executive Number'] || 'N/A', // V6.0 FEATURE: Added Sales Executive Number column
                lead['Product/VC#'] || 'N/A',
                lead['Customer Name'] || 'N/A',
                lead.Phone || 'N/A',
                lead.Model || 'N/A',
                lead['Parent Product Line'] || 'N/A',
                lead['Product Line'] || 'N/A',
                lead['Sent At'] || lead.LastContact || 'N/A',
                createStatusBadge(lead.Status),
                createLikelihoodBadge(lead.likelihood || getLikelihoodFromStatus(lead.Status)),
                actionButton
            ];
            
            // Add cells to row
            columns.forEach((content, index) => {
                const cell = document.createElement('td');
                cell.className = 'py-4 px-6 whitespace-nowrap text-sm';
                
                // Apply right alignment to the actions column
                if (index === columns.length - 1) {
                    cell.className += ' text-right';
                }
                
                // If content is a DOM element, append it, otherwise set as innerHTML
                if (content instanceof HTMLElement) {
                    cell.appendChild(content);
                } else {
                    cell.innerHTML = content;
                }
                
                row.appendChild(cell);
            });
            
            // Add click event to show lead activity modal
            row.addEventListener('click', (e) => {
                // Don't trigger detail view if clicking on the action button
                if (!e.target.closest('button')) {
                    showLeadActivityModal(lead);
                }
            });
            
            tableBody.appendChild(row);
        });
    }
    
    // V2.5 ENHANCEMENT: Add responsive listener
    window.addEventListener('resize', () => {
        if ((window.innerWidth < 768 && !isMobile) || (window.innerWidth >= 768 && isMobile)) {
            renderTable(data);
        }
    }); 
};

// V1.0 ENHANCEMENT: Create status badge for the table
function createStatusBadge(status) {
    const badge = document.createElement('span');
    let bgColor, textColor;
    
    switch(status.toLowerCase()) {
        case 'qualified':
        case 'slot: 11:00 am':
        case 'slot: 03:00 pm':
        case 'contacted sales':
            bgColor = 'bg-status-green/20';
            textColor = 'text-status-green';
            break;
        case 'contacted':
        case 'sent':
            bgColor = 'bg-status-yellow/20';
            textColor = 'text-status-yellow';
            break;
        case 'lost':
        case 'not responded':
            bgColor = 'bg-status-red/20';
            textColor = 'text-status-red';
            break;
        default:
            bgColor = 'bg-teal-primary/20';
            textColor = 'text-teal-primary';
    }
    
    badge.className = `inline-flex items-center px-2.5 py-0.5 rounded-[10px] text-xs font-medium ${bgColor} ${textColor} backdrop-blur-sm border border-${textColor}/20`;
    badge.innerHTML = status;
    
    return badge;
}

// V1.0 ENHANCEMENT: Create dynamic action button based on conversation status
function createActionButton(lead) {
    const button = document.createElement('button');
    
    // Check if the lead has a conversation
    const hasConversation = lead.activityLog && lead.activityLog.length > 1;
    
    // Check if a summary has been generated
    const hasSummary = lead.summary !== undefined;
    
    if (!hasConversation) {
        // No conversation exists
        button.className = 'px-3 py-1.5 rounded-[10px] text-xs font-medium bg-gray-200 text-gray-500 cursor-not-allowed';
        button.innerHTML = 'No Conversation';
        button.disabled = true;
    } else if (hasSummary) {
        // Summary exists, show View Summary button
        button.className = 'px-3 py-1.5 rounded-[10px] text-xs font-medium bg-teal-primary text-white hover:bg-teal-secondary transition-all duration-300';
        button.innerHTML = '<i class="fas fa-file-alt mr-1"></i> View Summary';
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            showSummaryModal(lead, false);
        });
    } else {
        // Conversation exists but no summary, show Generate Summary button
        button.className = 'px-3 py-1.5 rounded-[10px] text-xs font-medium bg-teal-primary/20 text-teal-primary hover:bg-teal-primary/30 transition-all duration-300';
        button.innerHTML = '<i class="fas fa-magic mr-1"></i> Generate Summary';
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            showSummaryModal(lead, true);
        });
    }
    
    return button;
}

// End of createActionButton function

// V2.5 ENHANCEMENT: Add responsive listener for table rendering
window.addEventListener('resize', () => {
    const isMobile = window.innerWidth < 768;
    if ((window.innerWidth < 768 && !isMobile) || (window.innerWidth >= 768 && isMobile)) {
        renderTable(leadsData);
    }
}); // End of resize listener

const renderCharts = (data) => {
    const statusCtx = document.getElementById('lead-status-chart')?.getContext('2d');
    const sourceCtx = document.getElementById('lead-source-chart')?.getContext('2d');

    if (leadStatusChart) leadStatusChart.destroy();
    if (leadSourceChart) leadSourceChart.destroy();

    if (!statusCtx || !sourceCtx) return;

    const statusCounts = data.reduce((acc, lead) => {
        acc[lead.Status] = (acc[lead.Status] || 0) + 1;
        return acc;
    }, {});

    const sourceCounts = data.reduce((acc, lead) => {
        acc[lead.Source] = (acc[lead.Source] || 0) + 1;
        return acc;
    }, {});

    // V2.5 ENHANCEMENT: Enhanced chart styling with new color palette
    const chartOptions = {
        plugins: {
            legend: {
                position: 'bottom',
                labels: {
                    font: {
                        family: 'Inter',
                        size: 12
                    },
                    padding: 20,
                    usePointStyle: true,
                    pointStyle: 'circle'
                }
            }
        },
        animation: {
            animateScale: true,
            animateRotate: true,
            duration: 1000,
            easing: 'easeOutQuart'
        },
        cutout: '70%',
        responsive: true,
        maintainAspectRatio: false
    };

    leadStatusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(statusCounts),
            datasets: [{
                data: Object.values(statusCounts),
                backgroundColor: ['#198754', '#FFC107', '#DC3545', '#4A69FF'],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: chartOptions
    });

    leadSourceChart = new Chart(sourceCtx, {
        type: 'pie',
        data: {
            labels: Object.keys(sourceCounts),
            datasets: [{
                data: Object.values(sourceCounts),
                backgroundColor: ['#4A69FF', '#E1C16E', '#1D244D', '#6B7280'],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            ...chartOptions,
            cutout: '50%'
        }
    });
};

const showLeadDetail = (lead) => {
    const detailContent = document.getElementById('lead-detail-content');
    const detailModal = document.getElementById('lead-detail-modal');
    if (!detailContent || !detailModal) return;

    // V2.5 ENHANCEMENT: Enhanced lead detail display with more information and better formatting
    detailContent.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <p class="mb-3"><strong class="text-primary-text">Opportunity Name:</strong> ${lead['Opportunity Name'] || 'N/A'}</p>
<p class="mb-3"><strong class="text-primary-text">Customer Name:</strong> ${lead['Customer Name'] || 'N/A'}</p>
                <p class="mb-3"><strong class="text-primary-text">Sales Team:</strong> ${lead['Sales Team'] || 'N/A'}</p>
                <p class="mb-3"><strong class="text-primary-text">Product/VC#:</strong> ${lead['Product/VC#'] || 'N/A'}</p>
                <p class="mb-3"><strong class="text-primary-text">Status:</strong> 
                    <span class="px-2 py-1 rounded-xl text-xs font-medium ${lead.Status === 'Qualified' ? 'bg-status-green bg-opacity-20 text-status-green' : 
                    lead.Status === 'Contacted' ? 'bg-status-yellow bg-opacity-20 text-status-yellow' : 
                    lead.Status === 'Lost' ? 'bg-status-red bg-opacity-20 text-status-red' : 
                    'bg-electric-blue bg-opacity-20 text-electric-blue'}">  
                    ${lead.Status}
                    </span>
                </p>
            </div>
            <div>
                <p class="mb-3"><strong class="text-primary-text">Phone:</strong> ${lead.Phone || 'N/A'}</p>
                <p class="mb-3"><strong class="text-primary-text">Model:</strong> ${lead.Model || 'N/A'}</p>
                <p class="mb-3"><strong class="text-primary-text">Parent Product Line:</strong> ${lead['Parent Product Line'] || 'N/A'}</p>
                <p class="mb-3"><strong class="text-primary-text">Product Line:</strong> ${lead['Product Line'] || 'N/A'}</p>
                <p class="mb-3"><strong class="text-primary-text">Sent At:</strong> ${lead['Sent At'] || lead.LastContact || 'N/A'}</p>
            </div>
        </div>
        <div class="border-t border-gray-200 pt-6">
            <h3 class="font-semibold text-lg mb-3">Activity Log</h3>
            <p class="text-secondary-text">${lead['Activity Log'] || 'No activity yet.'}</p>
            <button id="view-activity-btn" class="mt-4 px-4 py-2 bg-electric-blue bg-opacity-10 text-electric-blue rounded-xl hover:bg-opacity-20 transition-colors duration-300">
                <i class="fas fa-history mr-2"></i> View Detailed Activity
            </button>
        </div>
        ${lead.Notes ? `
        <div class="border-t border-gray-200 pt-6 mt-6">
            <h3 class="font-semibold text-lg mb-3">Notes</h3>
            <p class="text-secondary-text">${lead.Notes}</p>
        </div>` : ''}
    `;
    
    // Add event listener to the View Activity button
    setTimeout(() => {
        const viewActivityBtn = document.getElementById('view-activity-btn');
        viewActivityBtn?.addEventListener('click', () => {
            showLeadActivity(lead);
        });
    }, 100);
    
    detailModal.classList.remove('hidden');
    // V2.5 ENHANCEMENT: Smooth animation for modal
    setTimeout(() => detailModal.querySelector('.modal-content')?.classList.add('modal-active'), 10);
};

// V1.0 ENHANCEMENT: Added function to show lead activity modal with timeline view
const showLeadActivityModal = (lead) => {
    const modal = document.getElementById('lead-activity-modal');
    const content = document.getElementById('lead-activity-content');
    
    if (!modal || !content) return;
    
    // Clear previous content
    content.innerHTML = '';
    
    // Create lead info header
    const header = document.createElement('div');
    header.className = 'mb-6 pb-4 border-b border-[rgba(175,179,183,0.2)]';
    header.innerHTML = `
        <h3 class="text-xl font-semibold mb-2">${lead['Customer Name']}</h3>
        <p class="text-secondary-text">${lead.Phone} • ${lead.Model}</p>
    `;
    content.appendChild(header);
    
    // Create mock activity timeline
    const activities = lead.activityLog || [
        { event: "Message Sent", timestamp: "2025-07-19 10:15 AM", details: "Initial outreach via WhatsApp." }
    ];
    
    // Create activity timeline
    const timeline = document.createElement('div');
    timeline.className = 'space-y-4';
    
    activities.forEach(activity => {
        const item = document.createElement('div');
        item.className = 'flex items-start';
        
        // Icon based on activity type
        let iconClass = 'fas fa-comment';
        if (activity.event.toLowerCase().includes('call') || activity.event.toLowerCase().includes('connect')) {
            iconClass = 'fas fa-phone-alt';
        }
        
        // Status color
        let statusColor = 'text-status-green';
        if (activity.event.toLowerCase().includes('sent')) statusColor = 'text-teal-primary';
        if (activity.event.toLowerCase().includes('missed')) statusColor = 'text-status-yellow';
        if (activity.event.toLowerCase().includes('failed')) statusColor = 'text-status-red';
        
        item.innerHTML = `
            <div class="flex-shrink-0 h-8 w-8 rounded-full ${statusColor} bg-${statusColor}/10 flex items-center justify-center mr-4">
                <i class="${iconClass}"></i>
            </div>
            <div>
                <p class="font-medium">${activity.event}: ${activity.details || ''}</p>
                <p class="text-sm text-secondary-text">${activity.timestamp}</p>
            </div>
        `;
        
        timeline.appendChild(item);
    });
    
    content.appendChild(timeline);
    
    // Show modal with animation
    modal.classList.remove('hidden');
    setTimeout(() => {
        modal.querySelector('.modal-content').classList.remove('scale-95', 'opacity-0');
        modal.querySelector('.modal-content').classList.add('scale-100', 'opacity-100');
    }, 10);
};

// V1.0 ENHANCEMENT: Added function to show summary modal with AI-generated content
const showSummaryModal = (lead, generateNew = false) => {
    const modal = document.getElementById('summary-modal');
    const content = document.getElementById('summary-content');
    const loading = document.getElementById('summary-loading');
    
    if (!modal || !content || !loading) return;
    
    // Clear previous content
    content.innerHTML = '';
    
    // Show the modal
    modal.classList.remove('hidden');
    setTimeout(() => {
        modal.querySelector('.modal-content').classList.remove('scale-95', 'opacity-0');
        modal.querySelector('.modal-content').classList.add('scale-100', 'opacity-100');
    }, 10);
    
    if (generateNew) {
        // Show loading state
        content.classList.add('hidden');
        loading.classList.remove('hidden');
        
        // Simulate AI generating a summary (would be an API call in production)
        setTimeout(() => {
            // Hide loading state
            loading.classList.add('hidden');
            content.classList.remove('hidden');
            
            // Generate a mock summary
            const mockSummary = {
                overview: `Customer ${lead['Customer Name']} expressed interest in the ${lead.Model}. They requested a test drive and selected a time slot.`,
                sentiment: 'Positive',
                nextSteps: 'Follow up after the test drive to discuss financing options.',
                keyPoints: [
                    'Customer is interested in specific features like safety and fuel efficiency',
                    'Prefers the ${lead.Model} over competitor models',
                    'Has budget constraints but willing to consider financing'
                ]
            };
            
            // Store the summary in the lead object
            lead.summary = mockSummary;
            
            // Render the summary
            renderSummary(content, lead);
            
            // Update the table to show the View Summary button
            renderTable(leadsData);
        }, 2000);
    } else if (lead.summary) {
        // Render existing summary
        renderSummary(content, lead);
    } else {
        // No summary exists and not generating a new one
        content.innerHTML = `
            <div class="text-center py-8">
                <i class="fas fa-file-alt text-4xl text-secondary-text mb-4"></i>
                <p class="text-secondary-text">No summary available for this conversation.</p>
                <button id="generate-summary-btn" class="mt-4 btn-primary">
                    <i class="fas fa-magic mr-2"></i> Generate Summary
                </button>
            </div>
        `;
        
        // Add event listener to the generate button
        setTimeout(() => {
            const generateBtn = document.getElementById('generate-summary-btn');
            generateBtn?.addEventListener('click', () => {
                showSummaryModal(lead, true);
            });
        }, 0);
    }
};

// V1.0 ENHANCEMENT: Helper function to render a summary
const renderSummary = (container, lead) => {
    const summary = lead.summary;
    
    // Create the summary content
    container.innerHTML = `
        <div class="mb-6">
            <h3 class="text-lg font-semibold mb-2">Conversation Overview</h3>
            <p class="text-secondary-text">${summary.overview}</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
                <h3 class="text-lg font-semibold mb-2">Customer Sentiment</h3>
                <div class="flex items-center">
                    <span class="px-3 py-1.5 rounded-[10px] text-sm font-medium bg-status-green/20 text-status-green">
                        <i class="fas fa-smile mr-2"></i> ${summary.sentiment}
                    </span>
                </div>
            </div>
            
            <div>
                <h3 class="text-lg font-semibold mb-2">Recommended Next Steps</h3>
                <p class="text-secondary-text">${summary.nextSteps}</p>
            </div>
        </div>
        
        <div>
            <h3 class="text-lg font-semibold mb-2">Key Points</h3>
            <ul class="space-y-2">
                ${summary.keyPoints.map(point => `
                    <li class="flex items-start">
                        <i class="fas fa-check-circle text-teal-primary mt-1 mr-2"></i>
                        <span class="text-secondary-text">${point}</span>
                    </li>
                `).join('')}
            </ul>
        </div>
    `;
};

const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        
        // Parse all data from the Excel file
        const allLeadsData = XLSX.utils.sheet_to_json(worksheet);
        
        // Get the lead count from the input field
        const leadCountInput = document.getElementById('lead-count-input');
        const leadCount = leadCountInput && leadCountInput.value ? parseInt(leadCountInput.value, 10) : null;
        
        // Slice the data array if a valid lead count was provided
        leadsData = leadCount && leadCount > 0 && leadCount < allLeadsData.length 
            ? allLeadsData.slice(0, leadCount) 
            : allLeadsData;
            
        // Update UI with the processed data
        renderTable(leadsData);
        renderCharts(leadsData);
        
        // Hide the modal and show a success message
        const uploadModal = document.getElementById('upload-modal');
        uploadModal.querySelector('.modal-content')?.classList.remove('modal-active');
        setTimeout(() => uploadModal?.classList.add('hidden'), 300);
        
        // Show a notification about how many leads were processed
        showNotification(`Processed ${leadsData.length} leads${leadCount ? ' (limited by your input)' : ''}.`);
    };
    reader.readAsArrayBuffer(file);
};

// Function to show a temporary notification message
const showNotification = (message) => {
    // Check if a notification container already exists, if not create one
    let notificationContainer = document.getElementById('notification-container');
    
    if (!notificationContainer) {
        notificationContainer = document.createElement('div');
        notificationContainer.id = 'notification-container';
        notificationContainer.className = 'fixed top-20 right-4 z-50 flex flex-col items-end space-y-2';
        document.body.appendChild(notificationContainer);
    }
    
    // Create the notification element
    const notification = document.createElement('div');
    notification.className = 'bg-electric-blue text-white px-4 py-2 rounded-xl shadow-soft transform translate-x-full opacity-0 transition-all duration-300';
    notification.textContent = message;
    
    // Add to container
    notificationContainer.appendChild(notification);
    
    // Trigger animation to show the notification
    setTimeout(() => {
        notification.classList.remove('translate-x-full', 'opacity-0');
    }, 10);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.classList.add('translate-x-full', 'opacity-0');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 5000);
};

// V1.0 ENHANCEMENT: Create likelihood badge for the table
function createLikelihoodBadge(likelihood) {
    const badge = document.createElement('span');
    let bgColor, textColor;
    
    switch(likelihood.toLowerCase()) {
        case 'high':
            bgColor = 'bg-status-green/20';
            textColor = 'text-status-green';
            break;
        case 'medium':
            bgColor = 'bg-status-yellow/20';
            textColor = 'text-status-yellow';
            break;
        case 'low':
            bgColor = 'bg-status-red/20';
            textColor = 'text-status-red';
            break;
        default:
            bgColor = 'bg-teal-primary/20';
            textColor = 'text-teal-primary';
    }
    
    badge.className = `inline-flex items-center px-2.5 py-0.5 rounded-[10px] text-xs font-medium ${bgColor} ${textColor} backdrop-blur-sm border border-${textColor}/20`;
    badge.innerHTML = likelihood;
    
    return badge;
}

// V1.0 ENHANCEMENT: Helper function to determine likelihood based on status
function getLikelihoodFromStatus(status) {
    switch(status.toLowerCase()) {
        case 'qualified':
        case 'slot: 11:00 am':
        case 'slot: 03:00 pm':
        case 'contacted sales':
            return 'High';
        case 'contacted':
        case 'sent':
            return 'Medium';
        case 'lost':
        case 'not responded':
            return 'Low';
        default:
            return 'Medium';
    }
}

const initDashboard = () => {
    // V2.5 ENHANCEMENT: Added header scroll effect for glassmorphism
    const header = document.querySelector('header');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 10) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    const uploadBtn = document.getElementById('upload-btn');
    const uploadModal = document.getElementById('upload-modal');
    const cancelUploadBtn = document.getElementById('cancel-upload-btn');
    const confirmUploadBtn = document.getElementById('confirm-upload-btn');
    const fileInput = document.getElementById('file-input');
    const searchInput = document.getElementById('search-input');
    const closeDetailBtn = document.getElementById('close-detail-btn');
    const leadDetailModal = document.getElementById('lead-detail-modal');
    const leadActivityModal = document.getElementById('lead-activity-modal');
    const closeActivityBtn = document.getElementById('close-activity-btn');
    const closeModalButtons = document.querySelectorAll('.modal-close');

    // V2.5 ENHANCEMENT: Enhanced modal animations
    uploadBtn?.addEventListener('click', () => {
        uploadModal?.classList.remove('hidden');
        setTimeout(() => uploadModal?.querySelector('.modal-content')?.classList.add('modal-active'), 10);
    });
    
    cancelUploadBtn?.addEventListener('click', () => {
        uploadModal?.querySelector('.modal-content')?.classList.remove('modal-active');
        setTimeout(() => uploadModal?.classList.add('hidden'), 300);
    });
    
    confirmUploadBtn?.addEventListener('click', () => fileInput?.click());
    fileInput?.addEventListener('change', handleFileUpload);
    
    closeDetailBtn?.addEventListener('click', () => {
        leadDetailModal?.querySelector('.modal-content')?.classList.remove('modal-active');
        setTimeout(() => leadDetailModal?.classList.add('hidden'), 300);
    });
    
    // V2.5 ENHANCEMENT: Close button for Lead Activity Modal
    closeActivityBtn?.addEventListener('click', () => {
        leadActivityModal?.querySelector('.modal-content')?.classList.remove('modal-active');
        setTimeout(() => leadActivityModal?.classList.add('hidden'), 300);
    });
    
    // V1.0 ENHANCEMENT: Enhanced modal close buttons with improved animation
    closeModalButtons?.forEach(button => {
        button.addEventListener('click', () => {
            const modal = button.closest('.modal');
            if (modal) {
                const modalContent = modal.querySelector('.modal-content');
                if (modalContent) {
                    modalContent.classList.remove('scale-100', 'opacity-100');
                    modalContent.classList.add('scale-95', 'opacity-0');
                    setTimeout(() => modal.classList.add('hidden'), 300);
                } else {
                    modal.classList.add('hidden');
                }
            }
        });
    });
    
    // V1.0 ENHANCEMENT: Added event listeners for summary modal buttons
    const closeSummaryBtn = document.getElementById('close-summary-btn');
    const refreshSummaryBtn = document.getElementById('refresh-summary-btn');
    const summaryModal = document.getElementById('summary-modal');
    
    closeSummaryBtn?.addEventListener('click', () => {
        if (summaryModal) {
            const modalContent = summaryModal.querySelector('.modal-content');
            if (modalContent) {
                modalContent.classList.remove('scale-100', 'opacity-100');
                modalContent.classList.add('scale-95', 'opacity-0');
                setTimeout(() => summaryModal.classList.add('hidden'), 300);
            } else {
                summaryModal.classList.add('hidden');
            }
        }
    });
    
    refreshSummaryBtn?.addEventListener('click', () => {
        // Get the lead ID from the modal if available
        const leadId = summaryModal?.getAttribute('data-lead-id');
        if (leadId) {
            const lead = leadsData.find(l => l.id.toString() === leadId);
            if (lead) {
                showSummaryModal(lead, true); // Regenerate the summary
            }
        }
    });

    searchInput?.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filteredData = leadsData.filter(lead => {
            // V1.0 ENHANCEMENT: Enhanced search to include all relevant fields
            const opportunityName = (lead['Opportunity Name'] || '').toLowerCase();
            const customerName = (lead['Customer Name'] || '').toLowerCase();
            const phone = (lead.Phone || '').toLowerCase();
            const model = (lead.Model || '').toLowerCase();
            const status = (lead.Status || '').toLowerCase();
            
            return opportunityName.includes(searchTerm) || 
                   customerName.includes(searchTerm) || 
                   phone.includes(searchTerm) ||
                   model.includes(searchTerm) ||
                   status.includes(searchTerm);
        });
        renderTable(filteredData);
    });

    // V2.5 ENHANCEMENT: Initial render with mock data
    if (leadsData && leadsData.length > 0) {
        renderTable(leadsData);
        renderCharts(leadsData);
    }
}; // End of initDashboard function

// Export init function for use in main.js
export const init = () => {
    // Initialize dashboard functionality
    initDashboard();
};
