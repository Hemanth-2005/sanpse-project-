/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./dashboard.html",
    "./offers.html",
    "./payment.html",
    "./feedback.html",
    "./login.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // V3 ENHANCEMENT: Implemented new 'Modern Teal & Slate' color palette
        'primary-bg': '#0D1F23', // Very dark, deep teal-slate background
        'content-bg': 'rgba(90, 99, 106, 0.1)', // Slightly lighter dark slate with low opacity
        'primary-text': '#AFB3B7', // Light, soft gray for primary body text
        'secondary-text': '#8A9095', // Slightly darker gray for secondary text
        'teal-primary': '#2D4A53', // Brighter, mid-tone teal for interactive elements
        'teal-secondary': '#132E35', // Darker teal for hover states
        'highlight': '#AFB3B7', // Lightest gray for important icons or highlights
        'tata-blue': '#2D4A53', // Updated to match teal-primary
        'status-green': '#4CAF50',
        'status-yellow': '#FFC107',
        'status-red': '#F44336',
        'likelihood-high': '#4CAF50',
        'likelihood-medium': '#FFC107',
        'likelihood-low': '#F44336',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      boxShadow: {
        // V3 ENHANCEMENT: Enhanced shadow system for the dark theme
        'soft': '0px 8px 32px rgba(0, 0, 0, 0.2)',
        'card': '0 4px 20px rgba(0, 0, 0, 0.15)',
        'elevated': '0 10px 30px rgba(0, 0, 0, 0.25)',
      },
      borderRadius: {
        // V3 ENHANCEMENT: Standardized 10px border-radius for all elements
        'xl': '10px',
      },
      backgroundImage: {
        // V3 ENHANCEMENT: Updated gradient for primary buttons
        'button-gradient': 'linear-gradient(to right, #2D4A53, #3A5A64)',
      },
      spacing: {
        // V3 ENHANCEMENT: Enhanced spacing system
        '18': '4.5rem',
        '22': '5.5rem',
        '26': '6.5rem',
        '30': '7.5rem',
      },
      backdropBlur: {
        'xs': '2px',
        'sm': '5px',
        'md': '10px',
      },
      backdropFilter: {
        'blur-xs': 'blur(2px)',
        'blur-sm': 'blur(5px)',
        'blur-md': 'blur(10px)',
      }
    },
  },
  plugins: [],
}
